class SiteController < ApplicationController
  def index
  end

  def images
  end

  def videos
  end

  def livestreaming
  end

  def rankings
  end

  def products
  end
end
