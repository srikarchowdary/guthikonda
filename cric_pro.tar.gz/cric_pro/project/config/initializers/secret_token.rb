# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Project::Application.config.secret_token = 'cdd85435a2a3324cfd558f909ae33a571db5f79d04d9f6aeb1d4fd77c836526112d1aa668fa5123a139254fca81f5da57382f04a1ed15ab70f04d781b98b29b8'
