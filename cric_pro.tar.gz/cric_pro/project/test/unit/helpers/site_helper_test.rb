require 'test_helper'

class SiteHelperTest < ActionView::TestCase
end
